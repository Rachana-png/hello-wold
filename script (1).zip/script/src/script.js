var myStr="This is the start" + " " +"This is the end"

console.log(myStr);