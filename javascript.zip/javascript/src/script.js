

//manipulate array with push

var ourArray=[["rachu",2],["john",3],["cat",4]];
  ourArray.push(["dog",45]);
console.log(ourArray);

//------------------------------------------------------------------------------------

//manipulate array with pop

var ourArray=[["rachu",2],["john",3],["cat",4]];
var removedFromourArray=ourArray.pop();
console.log(ourArray);

//-----------------------------------------------------------------



//manipulate array with unshift

var ourArray=[["rachu",2],["john",3],["cat",4]];
  ourArray.shift();
ourArray.unshift(["happy",35]);
console.log(ourArray);
//---------------------------------------------------*----------------------------------------------------


//manipulate array with shift

var ourArray=[["rachu",2],["john",3],["cat",4]];
 var removeourArray=ourArray.shift();
console.log(ourArray);
//-------------------------------------------------*----------------------------------------------------------

// resuable function code with function
function reusableFunction(){
  console.log("hi world");
  
}
reusableFunction();


//---------------------------------------------------------------------------------------------------------

// passing values to function with arguments

function ourfunctionWithReguments(a,b){
  console.log(a-b);
  
}
ourfunctionWithReguments(10,5);

//------------------------------------------------------------------------------------------------------------

// Global scope and functions

function myLocalScope(){
  var myVar=5;                     //only visible inside the function
  console.log(myVar);
}
 myLocalScope();
//console.log(myVar);                // Error because outside the function

//-----------------------------------------------------------------------------------------------------------------

//Global vs Local scope in function

var outerWear="T-Shirt";    // Global variable because outside the function

function myOutFit(){
var outerWear="Sweater";     //local variable
  return outerWear;
}
console.log(myOutFit());    // sweater
console.log(outerWear);     //T-Shirt

//------------------------------------------------------------------------------------------------------------------



